#ifndef OPERACIONES_H
#define OPERACIONES_H


class operaciones
{

public:
    operaciones();
    int suma(int a, int b);
    char* leeFichero(char* nombre);

};

#endif // OPERACIONES_H
